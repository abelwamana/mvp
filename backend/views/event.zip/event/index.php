<?php

use yii\helpers\Html;

$this->title = 'Lista de Eventos';
$this->params['breadcrumbs'][] = $this->title;
?>
<?= Html::a('Calendário', ['/site/calendario2'], ['class' => 'btn btn-primary']) ?>

<h1><?= Html::encode($this->title) ?></h1>

<ul>
    <?php foreach ($eventos as $evento): ?>
        <li>
            <strong><?= Html::encode($evento->summary) ?></strong>
            <br>
            Início: <?= Html::encode($evento->start) ?>
            <br>
            Fim: <?= Html::encode($evento->end) ?>
            <br>
            Descrição: <?= Html::encode($evento->description) ?>
            <br>
            Localização: <?= Html::encode($evento->localizacao) ?>
            <br>
            Entidade Organizadora: <?= Html::encode($evento->entidadeOrganizadora) ?>
            <br>
            Participantes: <?= Html::encode($evento->participantes) ?>           
        </li>
    <?php endforeach; ?>
</ul>
