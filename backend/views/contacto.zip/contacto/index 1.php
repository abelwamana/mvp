<?php

use yii\grid\GridView;
use yii\helpers\Html;
use backend\models\Contacto;

/* @var $this yii\web\View */
/* @var $searchModel backend\models\ContactoSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Contactos';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="contacto-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Criar Contacto', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

   <?= GridView::widget([
    'dataProvider' => $dataProvider,
    'filterModel' => $searchModel,
    'columns' => [
        ['class' => 'yii\grid\SerialColumn'],

        'nome',
        'funcaoID',
        'instituicao',
        'contacto',
        'email',
        'pais',
         'provinciaID',
         'municipioID',
         'comunaID',
         'localidade',
         'pontofocal',
         'actividades',
         'entidade',
         'nivel',
         'rotulo',
         'privacidade',
         'estado',

        ['class' => 'yii\grid\ActionColumn'],
    ],
    'pager' => [
        'class' => 'yii\widgets\LinkPager',
        'firstPageLabel' => 'Primeiro',
        'lastPageLabel' => 'Último',
        'prevPageLabel' => 'Anterior',
        'nextPageLabel' => 'Próximo',
        'maxButtonCount' => 5,
    ],
    'options' => [
        'class' => 'grid-view',
    ],
]); ?>


</div>
