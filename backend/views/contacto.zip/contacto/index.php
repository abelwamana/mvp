<style>
    .container{
        position: relative;
        width: 100%;
        max-width: 100%;
        overflow-x: hidden; /* esconde o scroll horizontal */
        overflow-y: auto; /* permite o scroll vertical quando necessário */
    }
     /* Altere a cor de fundo do tipo 'info' do painel para a cor desejada */
   .custom-heading {
    color: #919733; /* Defina a cor desejada para o texto do heading */
}
    .btn.btn-success {
        background-color: #919733; /* Cor de fundo do botão primário Bootstrap */
        color: #fff; /* Cor do texto para legibilidade */
        /* Outros estilos conforme necessário */
    }
</style>
<?php

use backend\models\Contacto;
use yii\helpers\Html;
use kartik\grid\GridView;
use kartik\select2\Select2;

/** @var yii\web\View $this */
/** @var backend\models\ContactoSearch $searchModel */
/** @var yii\data\ActiveDataProvider $dataProvider */
$this->title = Yii::t('app', 'Contactos');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="container">
    <div class="contacto-index">

        <h1><?= Html::encode($this->title) ?></h1>

        <?=
        GridView::widget([
            'dataProvider' => $dataProvider,
            'filterModel' => $searchModel,
            'columns' => [
                [
                    'class' => 'yii\grid\CheckboxColumn',
                    'checkboxOptions' => function ($model, $key, $index, $column) {
                        return ['value' => $model->Id];
                    },
                ],
//            [
//                'class' => 'kartik\grid\SerialColumn',
//                'contentOptions' => ['class' => 'kartik-sheet-style'],
//                'width' => '36px',
//                'header' => '',
//                'headerOptions' => ['class' => 'kartik-sheet-style'],
//            ],
                [
                    'attribute' => 'Id',
                    'vAlign' => 'middle',
                    'hAlign' => 'center',
                ],
                [
                    'attribute' => 'nome',
                    'vAlign' => 'middle',
                    'hAlign' => 'center',
                ],
                [
                    'attribute' => 'funcaoID',
                    'vAlign' => 'middle',
                    'hAlign' => 'center',
                ],
                [
                    'attribute' => 'instituicao',
                    'vAlign' => 'middle',
                    'hAlign' => 'center',
                ],
                [
                    'attribute' => 'contacto',
                    'vAlign' => 'middle',
                    'hAlign' => 'center',
                ],
                [
                    'attribute' => 'email',
                    'vAlign' => 'middle',
                    'hAlign' => 'center',
                ],
                [
                    'attribute' => 'pais',
                    'vAlign' => 'middle',
                    'hAlign' => 'center',
                ],
                [
                    'attribute' => 'provinciaID',
                    'vAlign' => 'middle',
                    'hAlign' => 'center',
                    'value' => 'provincia.nomeProvincia', // Access the related nomeProvincia attribute
                ],
                [
                    'attribute' => 'municipioID',
                    'vAlign' => 'middle',
                    'hAlign' => 'center',
                    'value' => function ($model) {
                        return $model->municipio->nomeMunicipio;
                    },
                ],
                [
                    'attribute' => 'comunaID',
                    'vAlign' => 'middle',
                    'hAlign' => 'center',
                    'value' => function ($model) {
                        return $model->comuna->nomeComuna;
                    },
                ],
                [
                    'attribute' => 'localidade',
                    'vAlign' => 'middle',
                    'hAlign' => 'center',
                ],
                [
                    'attribute' => 'pontofocal',
                    'vAlign' => 'middle',
                    'hAlign' => 'center',
                ],
                [
                    'attribute' => 'actividades',
                    'vAlign' => 'middle',
                    'hAlign' => 'center',
                ],
                [
                    'attribute' => 'entidade',
                    'vAlign' => 'middle',
                    'hAlign' => 'center',
                ],
                [
                    'attribute' => 'nivel',
                    'vAlign' => 'middle',
                    'hAlign' => 'center',
                ],
                [
                    'attribute' => 'rotulo',
                    'vAlign' => 'middle',
                    'hAlign' => 'center',
                ],
                [
                    'attribute' => 'privacidade',
                    'vAlign' => 'middle',
                    'hAlign' => 'center',
                ],
                [
                    'attribute' => 'estado',
                    'vAlign' => 'middle',
                    'hAlign' => 'center',
                ],
//            [
//                'attribute' => 'estadoValidacao',
//                'vAlign' => 'middle',
//                'hAlign' => 'center',
//                'filterType' => GridView::FILTER_SELECT2,
//                'filterInputOptions' => [
//                    'id' => 'status',
//                ],
//                'filterWidgetOptions' => [
//                    'theme' => Select2::THEME_BOOTSTRAP,
//                    'pluginOptions' => ['allowClear' => true,],
//                    'options' => ['placeholder' => Yii::t('app', 'Select...')],
//                ],
//            ],
                [
                    'class' => 'kartik\grid\ActionColumn',
                    'template' => '{view} {update} {delete}',
                    'urlCreator' => function ($action, $model, $key, $index) {
                        if ($action === 'view') {
                            return ['view', 'Id' => $model->Id];
                        }
                        if ($action === 'update') {
                            return ['update', 'Id' => $model->Id];
                        }
                        if ($action === 'delete') {
                            return ['delete', 'Id' => $model->Id];
                        }
                    },
                ],
            ],
            'responsive' => true,
            'hover' => true,
            'pjax' => true,
            'filterModel' => $searchModel,
            'bordered' => true,
            'striped' => false,
            'condensed' => true,
            'responsiveWrap' => false,
            'panel' => [
                'type' => 'primary',
                'heading' => Yii::t('app', 'Contactos'),
                'before' => Html::a('<i class="fas fa-plus"></i> ' . Yii::t('app', 'Criar Contacto'), ['create'], ['class' => 'btn btn-success']),
                'after' => false,
            ],
        ]);
        ?>

    </div>
</div>
